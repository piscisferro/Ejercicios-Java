
-- Base de datos: `ejerciciojava`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `videojuegos`
--

CREATE TABLE IF NOT EXISTS videojuegos (
  CodVi int(11) NOT NULL,
  Nombre varchar(50) NOT NULL,
  Genero varchar(50),
  Año int(11),
  Compañia varchar(50),
  Formato varchar(50),
  DRM varchar(2)
)

--
-- Volcado de datos para la tabla `videojuegos`
--

INSERT INTO `videojuegos` (`CodVi`, `Nombre`, `Genero`, `Año`, `Compañia`, `Formato`, `DRM`) VALUES
(1, 'Dawn of war', 'RTS', 2013, 'Relic', 'Fisico', 'No'),
(2, 'CoH', 'RTS', 2014, 'Relic', 'Digital', 'Si'),
(3, 'Heroes of the Storm', 'MOBA', 2015, 'Blizzard', 'Digital', 'Si'),
(4, 'Battlefield 4', 'FPS', 2013, 'Dice', 'Digital', 'Si'),
(5, 'XRebirth', 'Simulador', 2013, 'Egosoft', 'Digital', 'No'),
(6, 'Thief', 'Sigilo', 2013, 'Eidos', 'Digital', 'No');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `videojuegos`
--
ALTER TABLE `videojuegos`
  ADD PRIMARY KEY (`CodVi`);

